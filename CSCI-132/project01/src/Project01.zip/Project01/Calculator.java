package Project01;

import java.util.Random;
import java.util.Scanner;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class Calculator {
    // FIELDS
    private double answer;
    private Scanner scannedInput = new Scanner(System.in);
    public final double ROUGHLY_PI = 3.14159;
    public String usageInstructions = "Valid operations are: \n"
            + " + \t add \n - \t subtract \n * \t multiply \n / \t divide \n"
            + " c \t clear  \n neg \t negate \n % \t percent \n"
            + " ^ \t raise to power of next value entered \n inv \t invert the current value \n"
            + " rand \t radomize current value by a fractional amount \n"
            + " round \t round to number of places given next \n" + " = \t print answer \n ? \t Help \n q \t Quit \n";

    // CONSTRUCTORS
    Calculator() {
        this.answer = 0;
    };

    // METHODS
    // prompt user for a double and check before returning
    public double getUserNum() {
        boolean validNumber = false;
        double userVal = 0;

        System.out.print("Enter number\n>>> ");

        while (validNumber == false) {
            if (scannedInput.hasNext("pi")) {
                // TODO: make this a constant instead of 3.1: ROUGLY_PI to five decimal places.
                userVal = ROUGHLY_PI;
                scannedInput.next();
                validNumber = true;
            } else if (scannedInput.hasNextDouble()) {
                userVal = scannedInput.nextDouble();
                validNumber = true;
            } else {
                System.out.print("That's not a number. \nEnter a valid number\n>>> ");
                scannedInput.next();
            }
        }
        return userVal;
    }

    // prompt user for operation and check before returning
    public String getUserOp() {
        String op;

        System.out.print("Enter operation\n>>> ");
        op = scannedInput.next();
        while (!(this.checkUserOp(op))) {
            op = scannedInput.next();
        }
        return op;
    }

    // private helper method for getUserInput()
    private boolean checkUserOp(String op) {
        if (op.equals("+") || op.equals("-") || op.equals("=") || op.equals("?") || op.equals("Q") || op.equals("q")
                || op.equals("*") || op.equals("/") || op.equals("c") || op.equals("C") || op.equals("neg")
                || op.equals("%") || op.equals("^") || op.equals("inv") || op.equals("rand") || op.equals("round")) {
            return true;
        } else {
            System.out.print("Invalid Entry. Enter '?' for help." + "\nEnter a valid operation \n>>> ");
            return false;
        }
    }

    public double calculateAnswer(String op, double num) {
        switch (op) {
            case "+":
                add(num);
                break;
            case "-":
                subtract(num);
                break;
            case "*":
                multiply(num);
                break;
            case "/":
                divide(num);
                break;
            case "c":
            case "C":
                clearAnswer();
                break;
            case "neg":
                neg(num);
                break;
            case "%":
                // TODO: code in this functionality
                percentOfNumber(num);
                break;
            case "^":
                // TODO: code in this functionality
                pow(num);
                break;
            case "inv":
                inverse(num);
                // TODO: code in this functionality
                break;
            case "rand":
                // TODO: add or subtract some random decimal amount between 0 and 1
                randomNum(num);
                break;
            case "round":
                // TODO: round to a given number of decimal places

                round(num);
                break;
            case "=":
                printAnswer();
                break;
            case "?":
                System.out.println(this.usageInstructions);
                break;
            default:
                System.out.println("Invalid Operator");
        }
        return this.answer;
    }

    public double add(double operand) {
        this.answer += operand;
        return this.answer;
    }

    public double subtract(double operand) {
        this.answer -= operand;
        return this.answer;
    }

    public double multiply(double operand){
        this.answer *= operand;
        return this.answer;
    }

    public double divide(double operand){
        this.answer /= operand;
        return  this.answer;
    }

    public double clearAnswer(){
        this.answer = 0.0;
        return this.answer;
    }

    public double neg(double operand){
        this.answer = operand * (-1);
        return this.answer;
    }

    public double percentOfNumber(double operand){
        this.answer = (operand / 100);
        return this.answer;
    }

    public double inverse(double operand){
        this.answer = 1/operand;
        return this.answer;
    }

    public double pow(double operand){
        this.answer = Math.pow(this.answer, operand);
        return this.answer;
    }

    public double round(double operand){
        BigDecimal setUpRound = new BigDecimal(this.answer).setScale((int) operand, RoundingMode.HALF_UP);
        this.answer = setUpRound.doubleValue();
        return this.answer;
    }

    public double getAnswer() {
        return this.answer;
    }

    public double randomNum(double operand){
        double changeDecider = new Random().nextInt(1);
        double changeNum = new Random().nextDouble();
        if (changeDecider == 1) {
            this.answer += changeNum;
            return this.answer;
        }

        else{
            this.answer -= changeNum;
            return this.answer;
        }
    }

    public static String formatOutput(double calculatorAnswer){

        String formattedAnswer = (

                "The Answer is " + calculatorAnswer + "\n");


        return formattedAnswer;
    }

    public void printAnswer() {
        // https://www.fileformat.info/info/unicode/block/box_drawing/list.htm
        // https://www.homeandlearn.co.uk/java/java_formatted_strings.html
        double solution = this.answer;
        //System.out.print(Calculator.formatOutput(solution));

        String header = "\n┌──────────────────────────┐ \n";
        String side = "|";
        String body = solution + " " + side;
        String footer = "└──────────────────────────┘ \n";
        // TODO: right justify the output inside a unicode box drawing
        System.out.print(header);
        System.out.printf("%-1s %26s %n",side,body);
        System.out.print(footer);
    }

}
